from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)
model = joblib.load("xgb_boston_model.pkl")

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    if request.method == "POST":
        try:
            features = []
            for field in ["lstat", "rm", "ptratio", "indus", "tax", "nox", "crim"]:
                val = request.form.get(field)
                if val == "" or val is None:
                    raise ValueError(f"{field} is missing.")
                features.append(float(val))

            pred = model.predict([features])[0]
            prediction = round(pred, 2)

        except Exception as e:
            prediction = f"Error: {str(e)}"
    
    return render_template("main_page.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
